import * as api from '$lib/api';
import {redirect} from "@sveltejs/kit";

/** @type {import('./$types').PageServerLoad} */

export async function load({ locals, url }) {
    //if (!locals.token) throw redirect(307, '/login');


    const q = new URLSearchParams();

    const  data= await Promise.all([api.get(`location`, locals.token),]);

    return {
        data
    };
}
